# Fintech Mini-Project (NestJS + MongoDB) — Points 1-3

This archive contains a minimal NestJS project implementing **points 1–3**:
1. Architecture / Coding Pattern
2. Tech Stack
3. Database selection & external integrations

## Included modules
- `customers` — CRUD for customers (schema, DTO, service, controller)
- `transactions` — create transactions with MongoDB transactions/session and idempotency
- `payments` — internal service that calls external payment gateway (mock via HTTP)

## Quick start
1. Unzip the project and `cd fintech-nest-mongo`
2. Copy `.env.example` to `.env` and edit if needed:
   ```bash
   cp .env.example .env
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start MongoDB (see MongoDB instructions further below)
5. Run dev server:
   ```bash
   npm run start:dev
   ```
6. API:
   - `POST /customers` — create customer
   - `GET /customers/:id` — get customer by id
   - `POST /transactions` — create a transaction (will call payment gateway mock)
   - `GET /transactions` — list transactions
   - `GET /transactions/:id` — get transaction by id

## 1) Architecture / Pattern (summary)
- **Pattern:** Modular NestJS application using Repository/Service/Controller split and Mongoose ODM.
- **Modules:** customers, transactions, payments.
- **Transaction flow:** client → TransactionsController → TransactionsService (starts MongoDB session & withTransaction) → PaymentsService (external HTTP call) → commit.
- **Idempotency:** `idempotencyKey` supported in CreateTransactionDto to prevent double-charging.

## 2) Tech Stack (summary)
- Language: TypeScript
- Framework: NestJS
- Database: MongoDB (Mongoose)
- HTTP client: @nestjs/axios (axios wrapper)
- Validation: class-validator + ValidationPipe

## 3) Database & External Integration (summary)
- **Database:** MongoDB; for multi-document transactions you need to run MongoDB as a replica set (even single-node replica set).
- **External services:** Payment Gateway (mock) and Notification (not included in this zip but easy to add). PaymentsService calls `PAYMENT_GATEWAY_URL` using HttpService and sends `Authorization: Bearer <key>`.

---

## Step-by-step MongoDB install (Local dev) — multiple options

### Option A — Docker (recommended)
1. Install Docker Desktop (Windows/macOS) or Docker Engine (Linux).
2. Run MongoDB container as a single-node replica set:
```bash
docker network create mongo-net || true
docker run -d --name mongo1 --net mongo-net -p 27017:27017 \
  -e MONGO_INITDB_ROOT_USERNAME=admin \
  -e MONGO_INITDB_ROOT_PASSWORD=secret \
  mongo:6 --replSet rs0 --bind_ip_all
# initialize replica set
docker exec -it mongo1 mongosh -u admin -p secret --eval "rs.initiate()"
```
3. Connection string example (matches `.env.example`):
```
mongodb://admin:secret@localhost:27017/fintech?authSource=admin
```

### Option B — macOS (Homebrew)
```bash
brew tap mongodb/brew
brew install mongodb-community@6.0
brew services start mongodb-community@6.0
# for replica set:
mongod --replSet rs0 --bind_ip_all
mongosh --eval "rs.initiate()"
```

### Option C — Ubuntu / Debian (apt)
Follow MongoDB official instructions (add repo, apt update), then:
```bash
sudo apt install -y mongodb-org
# edit /etc/mongod.conf -> set replication.replSetName: rs0
sudo systemctl restart mongod
mongosh --eval "rs.initiate()"
```

### Option D — Windows (MSI)
1. Install MongoDB Community MSI.
2. Create folder `C:\data\db` or allow installer to create a service.
3. To run as replica set for local transactions, start `mongod` with:
```powershell
mongod --replSet rs0 --bind_ip_all
mongosh --eval "rs.initiate()"
```

---

## Notes
- `.env.example` contains dummy payment gateway config (`https://reqres.in/api`) useful for testing.
- For production, replace `.env` values with real secrets and run MongoDB replica set / cluster.
- Points 4 & 5 (testing, CI/CD) are intentionally skipped per request and can be added later.

