import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { lastValueFrom } from 'rxjs';

@Injectable()
export class PaymentsService {
  constructor(private readonly httpService: HttpService) {}

  async chargeExternal(amount: number, cardInfo: any, idempotencyKey?: string) {
    try {
      const url = (process.env.PAYMENT_GATEWAY_URL || 'https://reqres.in/api') + '/charge';
      const resp$ = this.httpService.post(
        url,
        { amount, card: cardInfo },
        {
          headers: {
            Authorization: `Bearer ${process.env.PAYMENT_GATEWAY_KEY || 'dummy_key'}`,
            ...(idempotencyKey ? { 'Idempotency-Key': idempotencyKey } : {}),
          },
          timeout: 10000,
        },
      );
      const { data } = await lastValueFrom(resp$);
      // We expect mock response like { status: 'success', transactionId: '...' } — adapt in real gateway
      return data;
    } catch (err) {
      throw new InternalServerErrorException('Payment gateway error: ' + String(err?.message || err));
    }
  }
