import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

export type TransactionDocument = Transaction & Document;

@Schema({ timestamps: true })
export class Transaction {
  @Prop({ type: Types.ObjectId, required: true, ref: 'Customer' })
  customerId: Types.ObjectId;

  @Prop({ required: true })
  amount: number;

  @Prop({ required: true, enum: ['debit', 'credit'] })
  type: string;

  @Prop({ default: 'pending' })
  status: string;

  @Prop({ default: {} })
  metadata: Record<string, any>;

  @Prop()
  idempotencyKey?: string;
}

export const TransactionSchema = SchemaFactory.createForClass(Transaction);
