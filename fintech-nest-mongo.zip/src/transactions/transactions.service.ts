import { Injectable, NotFoundException, BadRequestException, InternalServerErrorException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Transaction, TransactionDocument } from './schemas/transaction.schema';
import { Customer, CustomerDocument } from '../customers/schemas/customer.schema';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { PaymentsService } from '../payments/payments.service';

@Injectable()
export class TransactionsService {
  constructor(
    @InjectModel(Transaction.name) private txModel: Model<TransactionDocument>,
    @InjectModel(Customer.name) private customerModel: Model<CustomerDocument>,
    private paymentsService: PaymentsService,
  ) {}

  async createTransaction(dto: CreateTransactionDto) {
    // idempotency check
    if (dto.idempotencyKey) {
      const existing = await this.txModel.findOne({ idempotencyKey: dto.idempotencyKey }).exec();
      if (existing) return existing;
    }

    const session = await this.txModel.db.startSession();
    let createdTx;
    try {
      await session.withTransaction(async () => {
        const customer = await this.customerModel.findById(dto.customerId).session(session);
        if (!customer) throw new NotFoundException('Customer not found');

        if (dto.type === 'debit' && customer.balance < dto.amount) {
          throw new BadRequestException('Insufficient balance');
        }

        // create transaction
        const tx = new this.txModel({
          customerId: dto.customerId,
          amount: dto.amount,
          type: dto.type,
          status: 'processing',
          metadata: dto.metadata || {},
          idempotencyKey: dto.idempotencyKey,
        });
        createdTx = await tx.save({ session });

        // update customer balance
        if (dto.type === 'debit') {
          customer.balance = customer.balance - dto.amount;
        } else {
          customer.balance = customer.balance + dto.amount;
        }
        await customer.save({ session });
      });

      // after commit, call external payment gateway (outside transaction)
      try {
        const payResp = await this.paymentsService.chargeExternal(createdTx.amount, { /* cardInfo placeholder */ }, createdTx.idempotencyKey);
        // update tx status
        await this.txModel.findByIdAndUpdate(createdTx._id, { status: payResp?.status || 'succeeded', metadata: { ...createdTx.metadata, gateway: payResp } }).exec();
      } catch (err) {
        // If external payment fails, mark transaction as failed (compensation strategies may be needed)
        await this.txModel.findByIdAndUpdate(createdTx._id, { status: 'failed', 'metadata.gatewayError': String(err?.message || err) }).exec();
        throw new InternalServerErrorException('Payment gateway call failed');
      }

      return this.txModel.findById(createdTx._id).exec();
    } finally:
      session.endSession();
    }
  }

  async findAll() {
    return this.txModel.find().lean().exec();
  }

  async findById(id: string) {
    return this.txModel.findById(id).exec();
  }
}
